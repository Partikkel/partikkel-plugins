<?php

return array(
    'environment' => 'test'
);
