<?php
namespace Craft;

class PartikkelController extends BaseController
{
    // Login authorization action
    public function checkTicket()
    {

    }
}
