<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_462a1ca018458cfc2eea4660297591fe35129192fbf19c7b5d06cb074bfbb934 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e22a348d11ecaf2d084a66631f99c5bf601bae7727afcfc285fa9b89e67d5978 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e22a348d11ecaf2d084a66631f99c5bf601bae7727afcfc285fa9b89e67d5978->enter($__internal_e22a348d11ecaf2d084a66631f99c5bf601bae7727afcfc285fa9b89e67d5978_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_3cc00c014ff583a6df5b7f956e6c2d09aaf39bbd4b335126697a446a978aee52 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3cc00c014ff583a6df5b7f956e6c2d09aaf39bbd4b335126697a446a978aee52->enter($__internal_3cc00c014ff583a6df5b7f956e6c2d09aaf39bbd4b335126697a446a978aee52_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e22a348d11ecaf2d084a66631f99c5bf601bae7727afcfc285fa9b89e67d5978->leave($__internal_e22a348d11ecaf2d084a66631f99c5bf601bae7727afcfc285fa9b89e67d5978_prof);

        
        $__internal_3cc00c014ff583a6df5b7f956e6c2d09aaf39bbd4b335126697a446a978aee52->leave($__internal_3cc00c014ff583a6df5b7f956e6c2d09aaf39bbd4b335126697a446a978aee52_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_96105787ec2b6c6dfc4ef9383c2b4a37c10baeef064532716869618562ff2b98 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_96105787ec2b6c6dfc4ef9383c2b4a37c10baeef064532716869618562ff2b98->enter($__internal_96105787ec2b6c6dfc4ef9383c2b4a37c10baeef064532716869618562ff2b98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_e5e004309ec108134eff973edf2d1134523432e1f1b30c85c76580605203a315 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e5e004309ec108134eff973edf2d1134523432e1f1b30c85c76580605203a315->enter($__internal_e5e004309ec108134eff973edf2d1134523432e1f1b30c85c76580605203a315_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_e5e004309ec108134eff973edf2d1134523432e1f1b30c85c76580605203a315->leave($__internal_e5e004309ec108134eff973edf2d1134523432e1f1b30c85c76580605203a315_prof);

        
        $__internal_96105787ec2b6c6dfc4ef9383c2b4a37c10baeef064532716869618562ff2b98->leave($__internal_96105787ec2b6c6dfc4ef9383c2b4a37c10baeef064532716869618562ff2b98_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_97ede5287bd05e14d472386f1ab7ba16482eb406e9bd513c90c4f858b993ca5d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_97ede5287bd05e14d472386f1ab7ba16482eb406e9bd513c90c4f858b993ca5d->enter($__internal_97ede5287bd05e14d472386f1ab7ba16482eb406e9bd513c90c4f858b993ca5d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_464cf26c9f7d96e67c77889ee15fb8815925e93e10e3a874d304767a10009876 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_464cf26c9f7d96e67c77889ee15fb8815925e93e10e3a874d304767a10009876->enter($__internal_464cf26c9f7d96e67c77889ee15fb8815925e93e10e3a874d304767a10009876_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_464cf26c9f7d96e67c77889ee15fb8815925e93e10e3a874d304767a10009876->leave($__internal_464cf26c9f7d96e67c77889ee15fb8815925e93e10e3a874d304767a10009876_prof);

        
        $__internal_97ede5287bd05e14d472386f1ab7ba16482eb406e9bd513c90c4f858b993ca5d->leave($__internal_97ede5287bd05e14d472386f1ab7ba16482eb406e9bd513c90c4f858b993ca5d_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_e106a75d4f92772045f332491193f58376d8c5836defb9da200a8a5e53597871 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e106a75d4f92772045f332491193f58376d8c5836defb9da200a8a5e53597871->enter($__internal_e106a75d4f92772045f332491193f58376d8c5836defb9da200a8a5e53597871_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_be2ec284ed6c170c72426ace5a85b57f8548facc720a0181067aebe7be7b6a34 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_be2ec284ed6c170c72426ace5a85b57f8548facc720a0181067aebe7be7b6a34->enter($__internal_be2ec284ed6c170c72426ace5a85b57f8548facc720a0181067aebe7be7b6a34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_be2ec284ed6c170c72426ace5a85b57f8548facc720a0181067aebe7be7b6a34->leave($__internal_be2ec284ed6c170c72426ace5a85b57f8548facc720a0181067aebe7be7b6a34_prof);

        
        $__internal_e106a75d4f92772045f332491193f58376d8c5836defb9da200a8a5e53597871->leave($__internal_e106a75d4f92772045f332491193f58376d8c5836defb9da200a8a5e53597871_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/Users/gaute/symfony/gautetest/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
