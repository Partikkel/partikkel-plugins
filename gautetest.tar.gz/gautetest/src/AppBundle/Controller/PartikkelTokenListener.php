<?php

namespace AppBundle\Controller;

use Symfony\Component\HttpKernel\Event\FilterControllerEvent;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Session\Session;
use \Firebase\JWT\JWT;

class PartikkelTokenListener
{
    private $logger;

    public function __construct($logger)
    {
        $this->logger = $logger;
    }

    public function onKernelController(FilterControllerEvent $event)
    {
        $controller = $event->getController();

        //$logger = $this->getContainer()->get('logger');
        $this->logger->info('PartikkelTokenListener start');

        /*
         * $controller passed can be either a class or a Closure.
         * This is not usual in Symfony but it may happen.
         * If it is a class, it comes in array format
         */
        if (!is_array($controller)) {
            return;
        }

        if ($controller[0] instanceof IPartikkelTokenController) {
            $token = $event->getRequest()->query->get('partikkel');
            $this->logger->info('PartikkelTokenListener token: ' . $token);
            if ($token) {
                self::checkTicketAndMarkPagePaid($_GET["partikkel"],$event->getRequest());
            }
        }
    }

    function checkTicketAndMarkPagePaid($ticket,$request)
    {
        $jwt = base64_decode($ticket);
        $page = $request->getPathInfo();
        $public_key_file = file_get_contents('/var/partikkel/public.pem.test');  // 
        $public_key = openssl_pkey_get_public($public_key_file);
        $logger = $this->logger;
        try{
            $decoded = JWT::decode($jwt, $public_key, array('RS256'));//verify ticket
            $puid=$decoded->sub;
            $request->getSession()->set('partikkeluser', $puid); // set logged on userid
            $parsed = $decoded->url;
            $req = Request::create($parsed);
            $uri = $_SERVER['REQUEST_URI'];

            $logger->info('claim-url is ' . $req->getPathInfo());
            $logger->info('current url is ' . $uri);
            $logger->info('strpos is ' . strpos($uri,$req->getPathInfo()));
            if (strpos($uri,$req->getPathInfo()) === false)//verify valid for path
                return;
        }
        catch (Exception $e) {
            $logger.error($e);
        }
        if(!empty($decoded)){
            
            $logger->info('setting paid-'.$page  . ' paid');
            $request->getSession()->set('paid-'.$page, 'true');
        }
    }


}