<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Session\Session;
use \Firebase\JWT\JWT;
use Monolog\Logger;

class PaidContentController  extends Controller implements IPartikkelTokenController
{
    /**
     * @Route("/paidcontent/{page}")
     */
    public function pageAction(Request $request, $page, $_route)
    {
        /*$logger = $this->get('logger');
        $logger->info($request->getUri());
        $logger->info($request->getRequestUri());
        $logger->info($request->getSchemeAndHttpHost());
        $logger->info($_route);*/
        
        if(!empty($_GET["partikkel"])){
            unset($_GET['partikkel']); 
            $options = array('query' => $_GET);
            //return $this->redirect($this->generateUrl($_route, $options));
            return $this->redirect($request->getPathInfo());
        }
        $path = $request->getPathInfo();
        //$logger->info('page paid: ' . $request->get('session')->get('paid-'.$path));
        if($this->get('session')->get('paid-'.$path)){
            return new Response('<html><body>Juhuu. Du har betalt </body></html>');
        } else {
            $pageurl=$request->getUri();
            return new Response('<html><body>Du har ikke betalt, trykk <a href="https://test.partikkel.io/particket/access?url=' . $pageurl .'">her</a> for tilgang </body></html>');
        }
    }

}