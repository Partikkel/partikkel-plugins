if (QTags) {
  QTags.addButton(
    'partikkel_partikkel', 'partikkel',
    '[partikkel]', '[/partikkel]',
    'w', 'Partikkel tag', 142
  );
}
